DEBUG = True
SECRET_KEY = 'super dooper secretive words'
SQLALCHEMY_DATABASE_URI = 'mysql://emscan:emilyslist@emilyslist.ce7mgpba1zl2.us-west-2.rds.amazonaws.com:3306/emilyslist'
#SQLALCHEMY_DATABASE_URI = 'mysql://EmilysListAdmin:password@localhost:3306/EmilysList'
# [username]:[password]@[host]:[port]/[db]

MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 587
MAIL_USE_TLS = True
MAIL_USE_SSL = False
MAIL_USERNAME = 'emscancode@gmail.com'
MAIL_PASSWORD = 'emscancode12'

UPLOAD_FOLDER = '/opt/python/current/app/uploads'
ASSET_FOLDER = '/opt/python/current/app/assets'
ALLOWED_EXTENTIONS = ['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif']

AWS_ACCESS_KEY = 'AKIAJAIYNQMU2T4B2CRA'
AWS_SECRET_KEY = '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'

S3_BUCKET_NAME = 'emilyslist-uploads'
S3_HOST_NAME = 's3-us-west-2.amazonaws.com'
S3_BUCKET_LINK = '//s3-us-west-2.amazonaws.com/emilyslist-uploads/'
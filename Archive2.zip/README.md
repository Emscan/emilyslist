#EmilysList

## Description:
A Craigslist clone application

### Setup Instructions:
1. clone repo
1. create a virtual environment
1. $ pip install -r requirements.txt

URL: 
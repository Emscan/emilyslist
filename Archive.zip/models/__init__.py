from db import db
from categories import *
from listings import *
from images import *
from seeds import *

db.create_all()

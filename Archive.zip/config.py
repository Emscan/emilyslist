DEBUG = True
SECRET_KEY = 'super dooper secretive words'
SQLALCHEMY_DATABASE_URI = 'mysql://EmilysListAdmin:password@localhost:3306/EmilysList'

MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 587
MAIL_USE_TLS = True
MAIL_USE_SSL = False
MAIL_USERNAME = 'emscancode@gmail.com'
MAIL_PASSWORD = 'emscancode12'

UPLOAD_FOLDER = '/Users/emily/Desktop/Coding/north-bay/internets/emily/EmilysList/uploads'
ALLOWED_EXTENTIONS = ['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif']